package com.example.get_dynamic_widget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
